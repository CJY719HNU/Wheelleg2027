"""Summarize the motor-only recovery and independent terrain regressions."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent

def build():
    lines = ['# 电机起身与地形验收', '', '本报告针对当前电机恢复版本。倒地姿态只在测试开始时设置；恢复过程中逐步断言 qpos、qvel、time 未被控制器改写，外力为零。成功案例返回 GROUND 后继续稳定运行 3 s。', '',
             '| 初始状态 | 结果 | 起身至 GROUND 耗时 s | 最大单髋转角 ° | 峰值髋力矩 N·m |', '|---|---|---:|---:|---:|']
    for name, label in [('collapsed','塌腿'), ('front','前倒'), ('back','后倒'), ('inverted','倒置'), ('side','侧倒')]:
        s = json.loads((ROOT/f'recovery_{name}.json').read_text())['summary']
        assert s['success'] == (name != 'side')
        assert not s['controller_mutated_state'] and s['zero_external_forces']
        assert s['max_torque'] <= 40.000001
        start = next(e['t'] for e in s['events'] if e['to'] == 'RECOVERY')
        end = next((e['t'] for e in s['events'] if e['to'] == 'GROUND'), None)
        duration = f'{end-start:.3f}' if end is not None else '—'
        result = '成功' if s['success'] else '保护失能，未实现侧向起身'
        lines.append(f"| {label} | {result} | {duration} | {s['max_hip_rotation_deg']:.2f} | {s['max_torque']:.2f} |")
    lines += ['', '转角为测试中相对恢复起点的最大实际髋关节位移，不是命令值，也不是累计往返路程。轨迹包含完整转圈及支撑对齐，可能超过 360°；后倒、倒置使用了重新收腿布置支点的 REPACK。', '', '## 地形', '']
    for name in ['slope','launch']:
        s = json.loads((ROOT/f'terrain_drive_{name}.json').read_text())['summary']
        assert s['final_mode'] == 'GROUND'
        lines.append(f"- {name}：0.2 m/s 指令通行，26 s 测试结束为 GROUND，最终 y={s['y']:.3f} m。")
    lines += ['- 飞坡高 6 cm，AIR 约 0.045 s，随后落地并稳定；12 cm 落差的探索试验未稳定通过。', '- 三种场地已编译、短时步进及射线测高；组合场地的侧面台阶尚未完成通行验收。', '', '![独立场地预览](terrain_preview.png)', '', '## 基础功能回归', '']
    for name in ['stand','turn','jump']:
        s = json.loads((ROOT/f'advanced_{name}_fused.json').read_text())['summary']
        assert s['passed']
        lines.append(f'- {name}：{s["seconds"]:g} s，通过该场景验收。')
    checks = json.loads((ROOT/'advanced_interface_checks.json').read_text())
    assert all(checks.values())
    lines += [f'- 接口与保护检查：{len(checks)} 项通过。', '', '## 限制', '', '以上是既有碰撞模型中的确定性场景验证，不是任意姿态/地形的保证。机体采用碰撞盒，完整连杆自碰撞、真实电机功率及线束允许转角尚未验证；纯侧倒仍保持失能。', '', '## 复现', '', '```powershell', 'python -B verify_motor_recovery.py collapsed front back inverted side', 'python -B verify_advanced.py stand turn jump --seconds 10', 'python -B verify_advanced_interfaces.py', 'python -B verify_terrain.py', 'python -B verify_terrain_drive.py', 'python -B build_motor_report.py', '```', '', '## 文件 SHA-256', '']
    for name in ['advanced_control.py','motor_recovery.py','terrain_scene.py','balance_control.py','real_wheelleg_balance.xml','balance_gains.json','terrains/slope.json','terrains/launch.json','terrains/course.json']:
        lines.append(f'- `{name}`：`{hashlib.sha256((ROOT/name).read_bytes()).hexdigest()}`')
    (ROOT/'motor_terrain_acceptance.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')

if __name__ == '__main__':
    build()
