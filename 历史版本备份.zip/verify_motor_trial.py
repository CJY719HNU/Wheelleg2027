import json,sys
import numpy as np
import mujoco
from advanced_control import SensorRobot,HybridController,load_gains,step,Command,DT,ROOT
r=SensorRobot();c=HybridController(r,load_gains());c.initialize(r.d);logs=[]
for i in range(10000):
    cmd=Command(stop=i==1000,recover=i==2500);c.submit(cmd);x=step(r,c)
    if i%100==0:logs.append(dict(t=r.d.time,phase=getattr(getattr(c,'recovery_driver',None),'phase',''),**x))
(ROOT/'motor_recovery_trial.json').write_text(json.dumps(dict(events=c.events,samples=logs),indent=2))
print(c.events);print(x)
