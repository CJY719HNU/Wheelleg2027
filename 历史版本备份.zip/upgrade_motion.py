"""One-time parameter migration; runtime settings live in the controller."""
from pathlib import Path
import json
r=Path(__file__).resolve().parent
p=r/'advanced_control.py';s=p.read_text(encoding='utf-8')
s=s.replace('np.clip(command.speed,-.2,.2)','np.clip(command.speed,-2.,2.)')
s=s.replace("self.height_i[:]=0;self.yref=self.estimator.path;self.speed=0.;self.turn=0.;self.saturation_time=0.;self.settle=0.","self.height_i[:]=0;self.yref=self.estimator.path;self.saturation_time=0.;self.settle=0.\n        if mode in ['DISABLED','RECOVERY','CROUCH']:self.speed=0.;self.turn=0.")
s=s.replace('abs(v)>1.2','abs(v)>3.0').replace("not .18<g['h']<.43","not .17<g['h']<.43")
s=s.replace("legs])-.275)","legs])-.20)")
s=s.replace("legs])>.342 or d.time-self.mode_time>.10","legs])>.37 or d.time-self.mode_time>.20")
s=s.replace("(cmd.speed if self.mode=='GROUND' else 0.)-self.speed,-.25*DT,.25*DT", "(cmd.speed if self.mode in ['GROUND','LANDING','SINGLE'] else self.speed if self.mode=='AIR' else 0.)-self.speed,-.6*DT,.6*DT")
s=s.replace('self.target_height+cmd.height_rate*DT,.27,.35','self.target_height+cmd.height_rate*DT,.20,.35')
s=s.replace("target=.275 if self.mode=='CROUCH'", "target=.20 if self.mode=='CROUCH'")
s=s.replace('self.height+self.height_offsets,.27,.35','self.height+self.height_offsets,.20,.35')
s=s.replace("force=180-12*g['rate'][0]", "force=300-12*g['rate'][0]")
s=s.replace("if self.mode=='LANDING':\n                    force=min", "if self.mode in ['LANDING','THRUST']:\n                    force=min")
s=s.replace('min(.2,keyboard.speed+.025)','min(2.,keyboard.speed+.2)').replace('max(-.2,keyboard.speed-.025)','max(-2.,keyboard.speed-.2)').replace('max(.27,c.target_height-.01)','max(.20,c.target_height-.01)')
p.write_text(s,encoding='utf-8')
for name in ['launch','course']:
    p=r/'terrains'/f'{name}.json';data=json.loads(p.read_text())
    for obj in data['objects']:
        if obj['name']=='launch':obj['size'][1:]=[.4,.2]
    p.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
p=r/'verify_terrain.py';s=p.read_text().replace("1.5,1.4)","1.5,1.2)").replace('else [.03]','else [.10]');p.write_text(s)
p=r/'verify_advanced_interfaces.py';s=p.read_text().replace('cmd.speed==.2','cmd.speed==2.');p.write_text(s)
