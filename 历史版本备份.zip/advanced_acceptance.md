> 历史版本报告：其中外力扶正/仿真复位已从当前代码删除。本文件保留原始测试记录，当前验收请阅读 [电机起身与地形验收](motor_terrain_acceptance.md)。

# 新版控制器仿真验收

最终代码完成后运行 12 个场景，每个 16 s；另运行 3 个仅支持力估计场景，各 10 s，以及 10 项接口保护检查。所有各自定义的验收条件通过。

**通过保护测试不代表始终保持站立**：`estop` 和 `lift_high` 的预期结果就是失能。`fall` 使用了明确记录的仿真状态复位，不能算真实翻身成功。

环境：Python 3.14.0，MuJoCo 3.9.0，物理/控制步长 1 ms。峰值逐控制步统计，曲线样本间隔 10 ms。

| 场景 | 最终状态 | 最大俯仰 ° | 最大轮关节速度 rad/s | 地面阶段速度估计 RMSE m/s | 起身辅助 |
|---|---|---:|---:|---:|---|
| stand | GROUND | 0.0116 | 0.2185 | 0.000042 | 无 |
| drive | GROUND | 0.0633 | 2.4108 | 0.000387 | 无 |
| turn | GROUND | 0.0647 | 2.5294 | 0.000300 | 无 |
| jump | GROUND | 0.8167 | 5.3404 | 0.000053 | 无 |
| lift | GROUND | 2.1928 | 18.6801 | 0.000235 | 无 |
| height | GROUND | 0.0732 | 0.2499 | 0.000062 | 无 |
| terrain | GROUND | 0.1441 | 1.1950 | 0.000214 | 无 |
| recovery | GROUND | 11.0737 | 17.8936 | 0.000197 | 受限外力扶正后释放 |
| fall | GROUND | 180.0000 | 20.9047 | 0.002466 | 扶正超时，仿真复位 |
| estop | DISABLED | 0.3331 | 8.4154 | 0.000143 | 无 |
| noise | GROUND | 0.0637 | 2.4100 | 0.000666 | 无 |
| lift_high | DISABLED | 16.8376 | 32.1565 | 0.000523 | 无 |

## 场景定义

- stand：原地站立。drive：1–6 s 指令 0.10 m/s，随后停车。turn：在此基础上 2–5 s 指令 0.4 rad/s，最后停车。
- jump：1.5 s 请求小跳，无外部扶正或复位。lift：2–2.15 s 对机体质心施加向上 280 N，随后撤去，无起身辅助。
- height：目标先到 0.28 m，1–5 s 改到 0.34 m，之后回到 0.28 m。terrain：从编译阶段将地面横倾 0.05 rad（2.86°），不是只修改一个未生效的显示参数。
- recovery：1.5 s 急停，3.5 s 请求仿真辅助起身。fall：2–2.3 s 施加绕 -X 的 90 N·m 外部翻倒力矩，触发失能和自动辅助。
- estop：1.5 s 起保持急停，验证不自动重新使能。noise：drive 场景加上加速度偏置 [0.08,0.12,0] m/s² 和标准差 0.08 m/s² 噪声。
- lift_high：2–2.3 s 向上施加 360 N，测试超出当前缓冲能力的落地；关闭辅助并验证失能零力矩、轮速未超过保护上限。

## 关键结果

- jump：最大两轮最小离地间隙 2.857 cm；AIR 模式持续 0.130 s；AIR 两轮输出力矩全程为零。
- lift：最大两轮最小离地间隙 9.464 cm；AIR 模式持续 0.276 s；AIR 两轮输出力矩全程为零。
- lift_high：最大两轮最小离地间隙 62.746 cm；AIR 模式持续 0.785 s；AIR 两轮输出力矩全程为零。
- terrain：最终左右腿长 0.292529/0.307465 m；估计地面高差 -19.287 mm；最终横滚 -0.699°。
- stand/drive/turn/jump/lift/height/terrain/noise 最终均为双轮接触、机体不接触地面；日志中的仿真辅助力全为零。
- recovery 在约 6.949 s 撤去扶正外力，约 7.349 s 返回普通平衡。fall 约 12.134 s 使用仿真复位；该动作修改 qpos/qvel，不是电机驱动翻身。

## 只用支持力估计的切换

| 场景 | 判据通过 | 最终状态 | AIR 时长 s |
|---|---|---|---:|
| stand | 是 | GROUND | 0.000 |
| jump | 是 | GROUND | 0.162 |
| lift | 是 | GROUND | 0.249 |

`estimated` 的普通运动状态切换使用支持力估计，不用接触存在性提前确认落地。此测试仍采用模拟 IMU 和理想姿态，不能外推为真实硬件的离地识别准确率。

## 接口检查

- `gamepad_deadzone_deadman_axes_edges`：通过。
- `stale_command_ramps_to_zero`：通过。
- `disconnect_stops_command`：通过。
- `emergency_overrides_recovery`：通过。
- `overspeed_zero_torque`：通过。
- `invalid_command_disables`：通过。
- `invalid_sensor_disables`：通过。
- `invalid_physics_not_stepped`：通过。
- `airborne_encoder_ignored`：通过。
- `large_slip_innovation_rejected`：通过。

## 未完成的实机验收

- 当前 XInput 查询没有检测到实体手柄；轴方向、死区、使能键、按键上升沿、断连和超时经过程序验证。接上 Xbox 手柄后还需实际确认操控手感。
- 没有完成真实 IMU 姿态融合、CAN 电机接口、准确质量/惯量辨识、持续打滑和大地形试验。
- 超大外力不能保证稳定落地；本次 62 cm 级强抬升案例按预期失能。仿真复位和外力扶正均可用 `--physical-only` 关闭。

## 曲线

![离地、估计和地形适应曲线](advanced_validation.png)

## 文件指纹

- `advanced_control.py`：`a5571f8c0e09bc55007454d358f6528497997641ac361cfc94d1fc9367478c81`
- `gamepad_control.py`：`d41668013208418ac498d78d65eb05aa256c05ce2fac3903192836f84dbed4f3`
- `balance_control.py`：`0dc174ef30690280f5880d321574e2f5dc2242e175df84bf67c9c99dfd2940f1`
- `real_wheelleg_balance.xml`：`9b71e7ad6d91cfef8d96aca4f791749fb4687544c4aa0033d541bb290525e3b1`
- `balance_gains.json`：`045c80a5724022eed3c232270f057c53db3596e8d5483499d05ff7468ba95f6a`
