# 电机起身与地形验收

本报告针对当前电机恢复版本。倒地姿态只在测试开始时设置；恢复过程中逐步断言 qpos、qvel、time 未被控制器改写，外力为零。成功案例返回 GROUND 后继续稳定运行 3 s。

| 初始状态 | 结果 | 起身至 GROUND 耗时 s | 最大单髋转角 ° | 峰值髋力矩 N·m |
|---|---|---:|---:|---:|
| 塌腿 | 成功 | 3.270 | 443.31 | 37.27 |
| 前倒 | 成功 | 5.187 | 785.26 | 31.48 |
| 后倒 | 成功 | 7.740 | 669.07 | 40.00 |
| 倒置 | 成功 | 6.720 | 447.77 | 40.00 |
| 侧倒 | 保护失能，未实现侧向起身 | — | 0.00 | 0.00 |

转角为测试中相对恢复起点的最大实际髋关节位移，不是命令值，也不是累计往返路程。轨迹包含完整转圈及支撑对齐，可能超过 360°；后倒、倒置使用了重新收腿布置支点的 REPACK。

## 地形

- slope：0.2 m/s 指令通行，26 s 测试结束为 GROUND，最终 y=4.610 m。
- launch：0.2 m/s 指令通行，26 s 测试结束为 GROUND，最终 y=4.476 m。
- 飞坡高 6 cm，AIR 约 0.045 s，随后落地并稳定；12 cm 落差的探索试验未稳定通过。
- 三种场地已编译、短时步进及射线测高；组合场地的侧面台阶尚未完成通行验收。

![独立场地预览](terrain_preview.png)

## 基础功能回归

- stand：10 s，通过该场景验收。
- turn：10 s，通过该场景验收。
- jump：10 s，通过该场景验收。
- 接口与保护检查：10 项通过。

## 限制

以上是既有碰撞模型中的确定性场景验证，不是任意姿态/地形的保证。机体采用碰撞盒，完整连杆自碰撞、真实电机功率及线束允许转角尚未验证；纯侧倒仍保持失能。

## 复现

```powershell
python -B verify_motor_recovery.py collapsed front back inverted side
python -B verify_advanced.py stand turn jump --seconds 10
python -B verify_advanced_interfaces.py
python -B verify_terrain.py
python -B verify_terrain_drive.py
python -B build_motor_report.py
```

## 文件 SHA-256

- `advanced_control.py`：`2aa89e4964b082cd07eee9e973f709dc437ee2867980d64df3ccc7f2edfd4000`
- `motor_recovery.py`：`fa90ea57ab356986336cbd5a4b0ad36c8a0bbfd6502324fa807d43415b439d4d`
- `terrain_scene.py`：`03fca5b7c4251732aa6a2204d85170d6932fb1bb4e5e3816c709cb7d7b3fef7c`
- `balance_control.py`：`0dc174ef30690280f5880d321574e2f5dc2242e175df84bf67c9c99dfd2940f1`
- `real_wheelleg_balance.xml`：`9b71e7ad6d91cfef8d96aca4f791749fb4687544c4aa0033d541bb290525e3b1`
- `balance_gains.json`：`045c80a5724022eed3c232270f057c53db3596e8d5483499d05ff7468ba95f6a`
- `terrains/slope.json`：`6fc6371542d28fb2a03d35b2555628894fb9935dbbac5143a47b69d98f8915ef`
- `terrains/launch.json`：`cd32d739d419815e221709b4b96eeabb4f2c4109612db6d8f04bce01d709ab62`
- `terrains/course.json`：`559a37e1bab5c8bd8d455f6a08c03d7acb22afe8379392716fffb0ba71a52c6b`
