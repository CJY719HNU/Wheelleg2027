"""Compatibility entry point: generate the current motor-only acceptance report."""
from build_motor_report import build

if __name__ == "__main__":
    build()
    print("Written motor_terrain_acceptance.md; old acceptance retained as historical evidence.")
